
// import bcrypt from 'bcryptjs';
// import User from '../models/User.js';
// import Restaurant from '../models/Restaurant.js';
// import { generateToken } from '../utils/generateToken.js';
// import { httpError } from '../utils/apiResponse.js';

// export async function register(req, res) {
//   const { name, email, password, role = 'customer', restaurantName } = req.body;
//   if (await User.exists({ email: email.toLowerCase() })) throw httpError(409, 'Email already registered');
//   // Public registration never grants staff or administrator privileges.
//   const safeRole = role === 'manager' ? 'manager' : 'customer';
//   const user = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12), role: safeRole });
//   if (safeRole === 'manager') {
//     const base = (restaurantName || `${name} restaurant`).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
//     let slug = base || `restaurant-${user._id.toString().slice(-6)}`;
//     if (await Restaurant.exists({ slug })) slug = `${slug}-${user._id.toString().slice(-6)}`;
//     const restaurant = await Restaurant.create({ name: restaurantName || `${name}'s Restaurant`, slug, owner: user._id });
//     user.restaurantId = restaurant._id; await user.save();
//   }
//   res.status(201).json({ token: generateToken(user), user: safeUser(user) });
// }
// export async function login(req, res) {
//   const user = await User.findOne({ email: req.body.email.toLowerCase() }).select('+passwordHash');
//   if (!user || !(await bcrypt.compare(req.body.password, user.passwordHash))) throw httpError(401, 'Invalid email or password');
//   if (!user.active) throw httpError(403, 'Account disabled');
//   res.json({ token: generateToken(user), user: safeUser(user) });
// }
// export async function me(req, res) { res.json({ user: safeUser(req.user) }); }
// function safeUser(user) { return { id: user._id, name: user.name, email: user.email, role: user.role, restaurantId: user.restaurantId }; }

// import * as authService from '../services/authService.js';
// import { ok, fail } from '../utils/apiResponse.js';
// import { setRefreshCookie, clearRefreshCookie } from '../utils/generateToken.js';

// export async function register(req, res, next) {
//   try {
//     const { user, accessToken, refreshToken } = await authService.register(req.body);
//     setRefreshCookie(res, refreshToken);
//     return ok(res, { user, accessToken }, 'Registered', 201);
//   } catch (e) {
//     next(e);
//   }
// }

// export async function login(req, res, next) {
//   try {
//     const { user, accessToken, refreshToken } = await authService.login(req.body);
//     setRefreshCookie(res, refreshToken);
//     return ok(res, { user, accessToken }, 'Logged in');
//   } catch (e) {
//     next(e);
//   }
// }

// export async function refresh(req, res, next) {
//   try {
//     const { user, accessToken, refreshToken } = await authService.refresh(req.cookies.refreshToken);
//     setRefreshCookie(res, refreshToken);
//     return ok(res, { user, accessToken }, 'Refreshed');
//   } catch (e) {
//     clearRefreshCookie(res);
//     next(e);
//   }
// }

// export async function logout(req, res, next) {
//   try {
//     if (req.user) await authService.logout(req.user._id);
//     clearRefreshCookie(res);
//     return ok(res, null, 'Logged out');
//   } catch (e) {
//     next(e);
//   }
// }

// export async function me(req, res) {
//   return ok(res, { user: req.user.toPublic() });
// }


import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { Restaurant } from '../models/Restaurant.js';
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  setRefreshCookie,
  clearRefreshCookie,
} from '../utils/generateToken.js';
import { httpError  } from '../utils/apiResponse.js';

function safeUser(user) {
  return {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    role: user.role,
    restaurantId: user.restaurantId?.toString() ?? null,
  };
}

function createTokens(user) {
  const payload = {
    sub: user._id.toString(),
    role: user.role,
    restaurantId: user.restaurantId?.toString() ?? null,
  };

  return {
    accessToken: signAccessToken(payload),
    refreshToken: signRefreshToken({
      sub: user._id.toString(),
    }),
  };
}

export async function register(req, res) {
  const name = req.body.name?.trim();
  const email = req.body.email?.trim().toLowerCase();
  const password = req.body.password;
  const requestedRole = req.body.role ?? 'customer';
  const restaurantName = req.body.restaurantName?.trim();

  // Validate required fields even when request validation middleware exists.
  if (!name || name.length < 2 || name.length > 80) {
    throw HttpError(400, 'Name must contain 2 to 80 characters.');
  }

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw HttpError(400, 'Please provide a valid email address.');
  }

  if (typeof password !== 'string' ||
      password.length < 8 ||
      password.length > 100) {
    throw HttpError(400, 'Password must contain 8 to 100 characters.');
  }

  // Public registration must never grant staff or administrator roles.
  if (!['customer', 'manager'].includes(requestedRole)) {
    throw HttpError(400, 'Invalid registration role.');
  }

  if (requestedRole === 'manager' &&
      (!restaurantName || restaurantName.length < 2)) {
    throw HttpError(400, 'Restaurant name must contain at least 2 characters.');
  }

  const existingUser = await User.findOne({ email }).lean();

  if (existingUser) {
    throw HttpError(409, 'Email already registered.');
  }

  const passwordHash = await bcrypt.hash(password, 12);

  let user;
  let restaurant;

  try {
    user = await User.create({
      name,
      email,
      passwordHash,
      role: requestedRole,
    });

    if (requestedRole === 'manager') {
      // Matches the Restaurant schema you shared: it requires name,
      // and does not currently define slug or owner.
      restaurant = await Restaurant.create({
        name: restaurantName,
      });

      user.restaurantId = restaurant._id;
      await user.save();
    }
  } catch (error) {
    // Roll back records created during this registration attempt.
    if (restaurant?._id) {
      await Restaurant.deleteOne({ _id: restaurant._id }).catch(() => {});
    }

    if (user?._id) {
      await User.deleteOne({ _id: user._id }).catch(() => {});
    }

    if (error?.code === 11000) {
      throw new HttpError(409, 'Email already registered.');
    }

    throw error;
  }

  const { accessToken, refreshToken } = createTokens(user);

  setRefreshCookie(res, refreshToken);

  return res.status(201).json({
    message: 'Registration successful.',
    token: accessToken,
    user: safeUser(user),
  });
}

export async function login(req, res) {
  const email = req.body.email?.trim().toLowerCase();
  const password = req.body.password;

  if (!email || typeof password !== 'string' || !password) {
    throw httpError(400, 'Email and password are required.');
  }

  const user = await User.findOne({ email }).select('+passwordHash');

  // Keep the response generic so it doesn't reveal whether an email exists.
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    throw httpError(401, 'Invalid email or password.');
  }

  if (!user.active) {
    throw httpError(403, 'Account disabled. Contact the administrator.');
  }

  const { accessToken, refreshToken } = createTokens(user);

  setRefreshCookie(res, refreshToken);

  return res.status(200).json({
    message: 'Login successful.',
    token: accessToken,
    user: safeUser(user),
  });
}

export async function me(req, res) {
  if (!req.user) {
    throw httpError(401, 'Authentication required.');
  }

  return res.status(200).json({
    user: safeUser(req.user),
  });
}

export async function refresh(req, res) {
  const token = req.cookies?.refreshToken;

  if (!token) {
    throw new HttpError('Refresh token is missing.', 401);
  }

  let payload;

  try {
    payload = verifyRefreshToken(token);
  } catch {
    clearRefreshCookie(res);
    throw new HttpError('Refresh token is invalid or expired.', 401);
  }

  if (!payload.sub) {
    clearRefreshCookie(res);
    throw new HttpError('Invalid refresh token payload.', 401);
  }

  const user = await User.findById(payload.sub);

  if (!user) {
    clearRefreshCookie(res);
    throw new HttpError('User account not found.', 401);
  }

  // If your User schema has an active/isActive field, enforce it here
  // using the exact field name from that schema.

  const accessToken = signAccessToken({
    sub: user._id.toString(),
    role: user.role,
    restaurantId: user.restaurantId?.toString() ?? null,
  });

  // Rotate the refresh token on every successful refresh.
  const refreshToken = signRefreshToken({
    sub: user._id.toString(),
  });

  setRefreshCookie(res, refreshToken);

  return res.status(200).json({
    success: true,
    message: 'Token refreshed.',
    data: {
      token: accessToken,
      user: safeUser(user),
    },
  });
}

export async function logout(req, res) {
  clearRefreshCookie(res);

  return res.status(200).json({
    success: true,
    message: 'Logged out successfully.',
  });
}
