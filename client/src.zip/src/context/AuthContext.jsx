
import {
  createContext,
  useEffect,
  useState,
} from 'react';

import { api } from '../services/api';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('rms_token');

    if (!token) {
      setLoading(false);
      return;
    }

    let active = true;

    api
      .get('/auth/me')
      .then((response) => {
        if (active) {
          setUser(response.data.user);
        }
      })
      .catch(() => {
        localStorage.removeItem('rms_token');

        if (active) {
          setUser(null);
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', {
      email: email.trim().toLowerCase(),
      password,
    });

    if (!data.token || !data.user) {
      throw new Error('Invalid login response from server.');
    }

    localStorage.setItem('rms_token', data.token);
    setUser(data.user);

    return data.user;
  };

  const register = async (payload) => {
    const cleanPayload = {
      ...payload,
      name: payload.name.trim(),
      email: payload.email.trim().toLowerCase(),
    };

    if (cleanPayload.role !== 'manager') {
      delete cleanPayload.restaurantName;
    } else if (cleanPayload.restaurantName) {
      cleanPayload.restaurantName =
        cleanPayload.restaurantName.trim();
    }

    const { data } = await api.post(
      '/auth/register',
      cleanPayload
    );

    if (!data.token || !data.user) {
      throw new Error('Invalid registration response from server.');
    }

    localStorage.setItem('rms_token', data.token);
    setUser(data.user);

    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('rms_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, loading, login, register, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}
